"""Conventional single-cell and clinical aggregate displays. No synthetic curves."""
from pathlib import Path
import json
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from PIL import Image

import argparse, shutil
S=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Replot figures from supplied CSV source data; no GEO download or private intermediate inputs required.')
parser.add_argument('--output-dir',type=Path,default=S/'reproduced_figures')
args=parser.parse_args()
R=args.output_dir.resolve();O=R;R.mkdir(parents=True,exist_ok=True)
def read(name):
 path=S/name
 return pd.read_csv(path,float_precision='round_trip')
params=json.loads((S/'Analysis_parameters.json').read_text(encoding='utf-8'))
t=read('Cells_tumor_baseline_week4.csv')
late=read('Cells_exact_Fig3E.csv')
annotations=read('Cluster_annotations.csv')
labels=dict(zip(annotations.cluster_id,annotations.English))
dots=read('Fig1_marker_dotplot.csv')
program_rows=read('Fig1_cluster_program_heatmap.csv')
program_order=program_rows[['program','label']].drop_duplicates()
b=dict(t=t,late=late,cut=pd.Series({'Module_1':params['module1_cutoff'],'Module_8':params['module8_cutoff']}),labels=labels,
 summary=read('Fig2_group_summary.csv'),comp=read('Fig2_quadrant_proportions.csv'),patient=read('Fig2_patient_joint_programs.csv'),
 dots=dots,genes=dots.gene.drop_duplicates().tolist(),program_rows=program_rows,programs=program_order.program.tolist(),program_names=program_order.label.tolist())
assert len(t)==36185 and len(late)==6062
assert t.cb.is_unique and late.cb.is_unique
assert 'TOX' in t and 'novershtern_eff_cd8' in t
for name in ['Sensitivity_cutoffs_and_patient_weighting.csv','Fig3_clinical_best_response.csv','Fig3_clinical_landmark_estimates.csv','Fig3_clinical_hazard_ratios.csv']:
 if (S/name).resolve()!=(O/name).resolve():shutil.copyfile(S/name,O/name)

t=b['t'];late=b['late'];cut=b['cut'];labels=b['labels'];summary=b['summary']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':10,'xtick.labelsize':7,'ytick.labelsize':7,'axes.linewidth':.65,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
navy='#3D5488';red='#C52E38';salmon='#EDAA91';teal='#64ADAA';grey='#707A89'
cluster_colors=['#7DBEB6','#87A0C4','#C797B8','#A4B284','#F3B982','#6C80AB','#D96D64','#C42D2B','#8B6CA8']
div=LinearSegmentedColormap.from_list('navy_white_red',[navy,'#FAFAFA',red])
exprc=LinearSegmentedColormap.from_list('expression',['#E8E9ED','#F1A58E','#B71832'])
old_effector_palette=LinearSegmentedColormap.from_list('original_effector',['#E6E7E9','#F4BCA8','#BD1F2D'])
audit=read('Effector_comparison_cluster_statistics.csv')
effector_limits=audit.loc[audit.cohort=='Original full tumor atlas',['q02','q98']].iloc[0].to_numpy(float)
groups=['Baseline','rela','nivo','combo'];names={'Baseline':'Baseline','rela':'Rela | week 4','nivo':'Nivo | week 4','combo':'Nivo + Rela | week 4'}
states=['Exhaustion-low / cytotoxic-low','Exhaustion-low / cytotoxic-high','Exhaustion-high / cytotoxic-low','Exhaustion-high / cytotoxic-high']
state_colors=['#DCE2E9','#79B4BD','#8C9DBC','#C84043']

def panel(ax,letter,title):
 ax.set_title(title,loc='left',pad=10)
 ax.text(-.06,1.05,letter,transform=ax.transAxes,fontweight='bold',fontsize=14,va='bottom')
 ax.spines[['top','right']].set_visible(False)

def save(fig,name):
 for ext in ['pdf','svg','png']:fig.savefig(O/(name+'.'+ext),dpi=300)
 fig.savefig(R/(name+'_preview.png'),dpi=110)
 plt.close(fig)

def umap(ax,d,value=None):
 d=d.sample(frac=1,random_state=941)
 if value is None:
  for i in range(1,10):
   q=d[d.cluster_id==i];ax.scatter(q.UMAP_1,q.UMAP_2,s=1.5,c=cluster_colors[i-1],lw=0,alpha=.65,rasterized=True)
  for i,q in d.groupby('cluster_id'):
   ax.text(q.UMAP_1.median(),q.UMAP_2.median(),f'C{i}',ha='center',fontsize=7,bbox=dict(facecolor='white',alpha=.8,edgecolor='none',pad=.5))
 else:
  # Display clipping is declared and never applied to exported source scores.
  if value=='novershtern_eff_cd8':
   # Restore the older display convention without changing the week-4 cohort.
   lim=effector_limits;d=d.iloc[np.random.default_rng(813).permutation(len(d))]
   im=ax.scatter(d.UMAP_1,d.UMAP_2,s=1.8,c=d[value],lw=0,cmap=old_effector_palette,vmin=lim[0],vmax=lim[1],rasterized=True)
  else:
   lim=np.quantile(d[value],[.02,.98]);d=d.sort_values(value)
   im=ax.scatter(d.UMAP_1,d.UMAP_2,s=3,c=d[value],lw=0,cmap=exprc,vmin=lim[0],vmax=lim[1],rasterized=True)
  cb=ax.figure.colorbar(im,ax=ax,orientation='horizontal',fraction=.035,pad=.14,shrink=.65)
  cb.ax.tick_params(labelsize=6);cb.set_label('Deposited score' if value.startswith('Module') or value in b['programs'] else 'Deposited normalized expression',fontsize=7)
 ax.set_xticks([]);ax.set_yticks([]);ax.set_xlabel('UMAP 1');ax.set_ylabel('UMAP 2')
 ax.spines[['top','right']].set_visible(False)

# FIGURE 1: a complete transcriptional atlas, not presence of a labeled cluster alone.
fig=plt.figure(figsize=(13.2,11.2))
gs=fig.add_gridspec(3,12,height_ratios=[2.35,2.05,2.3],left=.065,right=.965,top=.90,bottom=.095,hspace=.66,wspace=1.8)
fig.text(.065,.968,'Figure 1 | CD8 T-cell identities and exhaustion-associated transcriptional programs',fontsize=14,fontweight='bold')
fig.text(.065,.942,f'GSE225063 | Baseline + week-4 tumor atlas: {len(t):,} cells | Author embeddings, cluster IDs and scores retained',fontsize=9,color=grey)
ax=fig.add_subplot(gs[0,:4]);panel(ax,'a','Tumor CD8 atlas');umap(ax,t)
ax=fig.add_subplot(gs[0,4:8]);ax.axis('off');panel(ax,'b','Cluster identities')
for i in range(1,10):
 y=.96-(i-1)*.107;ax.scatter(.0,y,s=28,color=cluster_colors[i-1],transform=ax.transAxes,clip_on=False)
 text=labels[i]
 if i==7:text='Terminal Tex /\nTCR signaling'
 if i==8:text='Progenitor-1 Tex / terminal Tex'
 ax.text(.055,y,f'C{i}  '+text,va='center',transform=ax.transAxes,fontsize=7.2,linespacing=1.0)
ax=fig.add_subplot(gs[0,8:]);panel(ax,'c','Programs across clusters')
p=b['program_rows'].pivot(index='label',columns='cluster_id',values='program_zscore').reindex(b['program_names'])
im=ax.imshow(p,cmap=div,vmin=-2,vmax=2,aspect='auto');ax.set_yticks(range(len(p)),p.index,fontsize=6.7);ax.set_xticks(range(9),[f'C{i}' for i in range(1,10)]);ax.set_xlabel('Original cluster')
cb=fig.colorbar(im,ax=ax,fraction=.03,pad=.03);cb.ax.set_title('z-score',fontsize=6);cb.ax.tick_params(labelsize=6)
ax=fig.add_subplot(gs[1,:]);panel(ax,'d','Marker expression supports cell-state identities')
d=b['dots'];genes=b['genes']
for i in range(1,10):
 q=d[d.cluster_id==i].set_index('gene').loc[genes]
 im=ax.scatter(range(len(genes)),np.repeat(i-1,len(genes)),s=2+125*q.fraction_detected,c=q.gene_zscore,cmap=div,vmin=-2,vmax=2,lw=0)
ax.set_xticks(range(len(genes)),genes,rotation=45,ha='right',fontstyle='italic');ax.set_yticks(range(9),[f'C{i}' for i in range(1,10)]);ax.set_xlim(-.6,len(genes)-.4);ax.set_ylim(8.6,-.6)
handles=[ax.scatter([],[],s=2+125*f,c='#858E9B',label=f'{100*f:.0f}%') for f in [.25,.5,1]]
ax.legend(handles=handles,title='Cells with expression > 0',ncol=3,frameon=False,loc='upper right',bbox_to_anchor=(.99,1.32),fontsize=6,title_fontsize=6)
cb=fig.colorbar(im,ax=ax,fraction=.015,pad=.018);cb.ax.set_title('z-score',fontsize=6)
post=t[t.time_tx=='combo'];lims={c:(t[c].min(),t[c].max()) for c in ['UMAP_1','UMAP_2']}
for i,(value,title) in enumerate([('Module_1','Terminal exhaustion module'),('novershtern_eff_cd8','Effector program'),('PDCD1','PDCD1 expression'),('HAVCR2','HAVCR2 expression')]):
 ax=fig.add_subplot(gs[2,i*3:(i+1)*3]);panel(ax,'efgh'[i],title);umap(ax,post,value)
 for c,fn in [('UMAP_1',ax.set_xlim),('UMAP_2',ax.set_ylim)]:
  lo,hi=lims[c];fn(lo-.03*(hi-lo),hi+.03*(hi-lo))
fig.text(.065,.038,f'e–h: Nivo + Rela, week-4 tumor CD8 cells (n={len(post):,}; {post.patient_id.nunique()} patients). f: original full-TIL reference color limits and random point order.\ne/g/h: within-panel 2nd–98th percentile color limits. Dot size: detection fraction; heatmap/dot color: program-wise/gene-wise z-score across nine clusters (display ±2).',fontsize=7,color=grey)
save(fig,'Figure_1_CD8_atlas_and_programs')

# FIGURE 2: exact author Fig 3E population and cutoff, displayed as observed-cell hexbins.
fig=plt.figure(figsize=(12.6,12.8))
gs=fig.add_gridspec(3,2,height_ratios=[2.65,2.65,2.15],left=.075,right=.925,top=.90,bottom=.105,hspace=.53,wspace=.30)
fig.text(.075,.968,'Figure 2 | Cytotoxicity and terminal-exhaustion programs coexist after Nivo + Rela',fontsize=13.4,fontweight='bold')
fig.text(.075,.944,'Exact Cell Figure 3E cohort and reference cutoffs | Last pseudotime bin | Tumor CD8 T cells',fontsize=9,color=grey)
extent=(-.20,2.80,-.50,1.67);hexrows=[];hexim=[]
for j,group in enumerate(groups):
 ax=fig.add_subplot(gs[j//2,j%2]);q=late[late.time_tx==group];s=summary[summary.time_tx==group].iloc[0]
 panel(ax,'abcd'[j],names[group]+f' | {len(q):,} cells, {q.patient_id.nunique()} patients')
 # Common lattice and percent-of-panel color units, no fitted density or invented smoothing.
 ax.set_facecolor('white')
 hb=ax.hexbin(q.Module_1,q.Module_8,C=np.repeat(100/len(q),len(q)),reduce_C_function=np.sum,mincnt=1,gridsize=26,extent=extent,cmap='Blues',linewidths=0)
 hexim.append(hb)
 offsets=hb.get_offsets();vals=hb.get_array()
 for (xx,yy),vv in zip(offsets,vals):hexrows.append(dict(time_tx=group,module1_bin_center=xx,module8_bin_center=yy,n_cells_in_hexagon=int(round(vv*len(q)/100)),percent_group_cells=vv))
 ax.axvline(cut.Module_1,color='#4B5563',lw=.8,ls='--');ax.axhline(cut.Module_8,color='#4B5563',lw=.8,ls='--')
 ax.set_xlim(extent[:2]);ax.set_ylim(extent[2:]);ax.set_xlabel('Terminal exhaustion module (Module 1)');ax.set_ylabel('Cytotoxic module (Module 8)')
 # All quadrant percentages computed from unsmoothed individual cells.
 for state,xy,ha,va in [(states[0],(.025,.035),'left','bottom'),(states[1],(.025,.965),'left','top'),(states[2],(.975,.035),'right','bottom'),(states[3],(.975,.965),'right','top')]:
  val=float(b['comp'].loc[(b['comp'].time_tx==group)&(b['comp'].joint_state==state),'percent'].iloc[0])
  ax.text(*xy,f'{val:.1f}%',transform=ax.transAxes,ha=ha,va=va,color=red if state==states[3] else '#303947',fontsize=12 if state==states[3] else 9,fontweight='bold' if state==states[3] else 'normal',bbox=dict(facecolor='white',alpha=.88,edgecolor='none',pad=1.5))
maxhex=max(float(im.get_array().max()) for im in hexim)
for im in hexim:im.set_clim(0,maxhex)
cax=fig.add_axes([.947,.435,.011,.365]);cb=fig.colorbar(hexim[0],cax=cax);cb.ax.set_title('Cells per hexagon\n(% of panel)',fontsize=6,pad=8);cb.ax.tick_params(labelsize=6)
pd.DataFrame(hexrows).to_csv(O/'Fig2_hexbin_values.csv',index=False)
ax=fig.add_subplot(gs[2,0]);panel(ax,'e','Joint transcriptional states | pooled cells')
left=np.zeros(4)
for state,col in zip(states,state_colors):
 q=b['comp'][b['comp'].joint_state==state].set_index('time_tx').loc[groups];ax.barh(range(4),q.percent,left=left,color=col,height=.58,edgecolor='white',lw=.5)
 for i,(l,w) in enumerate(zip(left,q.percent)):
  if w>7:ax.text(l+w/2,i,f'{w:.1f}',ha='center',va='center',fontsize=7,color='white' if state==states[-1] else '#243442')
 left+=q.percent.to_numpy()
ax.set_yticks(range(4),['Baseline','Rela','Nivo','Nivo + Rela']);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('Cells within pseudotime bin 10 (%)')
ax=fig.add_subplot(gs[2,1]);panel(ax,'f','Patient heterogeneity | Nivo + Rela')
patients=late[late.time_tx=='combo'].patient_id.unique().tolist();patients=sorted(patients,key=lambda s:int(s.split('_')[1]));left=np.zeros(len(patients))
for state,col in zip(states,state_colors):
 counts=late[late.time_tx=='combo'].assign(hit=lambda z:z.joint_state==state).groupby('patient_id').hit.mean().reindex(patients)*100
 ax.barh(range(len(patients)),counts,left=left,color=col,height=.73,edgecolor='white',lw=.3);left+=counts.to_numpy()
ct=late[late.time_tx=='combo'].groupby('patient_id').size()
ax.set_yticks(range(len(patients)),[p.replace('Patient_','P')+f' (n={ct[p]})' for p in patients],fontsize=6.2);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_xlabel('Cells within each patient (%)')
fig.legend(handles=[Patch(facecolor=c,label=s) for s,c in zip(states,state_colors)],loc='lower center',bbox_to_anchor=(.52,.047),ncol=2,frameon=False,fontsize=7)
fig.text(.075,.013,'Dashed cutoffs reproduce the author executable code (70th percentiles in reference bins 8–10). High/low are reference-relative, not diagnostic severity.\nPooled percentages describe deposited cells, not percentages of patients. f includes low-yield specimens; denominators are shown. Pseudotime is not treatment duration.',fontsize=7,color=grey)
save(fig,'Figure_2_exact_Fig3E_joint_programs')

# Supplement: make weighting and threshold dependence reviewable, without promoting cells to replicates.
fig,axes=plt.subplots(1,3,figsize=(13.2,4.7));fig.subplots_adjust(left=.075,right=.97,top=.78,bottom=.22,wspace=.45)
fig.text(.075,.94,'Supplementary Figure | Patient weighting and reference-threshold sensitivity',fontsize=13,fontweight='bold')
colors=[grey,salmon,navy,red];rng=np.random.default_rng(210)
for j,(col,title) in enumerate([('module1_median','Patient-level terminal-exhaustion scores'),('joint_high_fraction','Patient-level joint-high fractions')]):
 ax=axes[j];panel(ax,'ab'[j],title)
 for i,group in enumerate(groups):
  q=b['patient'][b['patient'].time_tx==group];values=q[col].to_numpy()*(100 if j==1 else 1)
  ax.boxplot(values,positions=[i],widths=.48,showfliers=False,medianprops={'color':'black'},boxprops={'color':colors[i]},whiskerprops={'color':colors[i]},capprops={'color':colors[i]})
  for _,r in q.iterrows():
   val=r[col]*(100 if j==1 else 1);filled=r.n_cells>=20
   ax.scatter(i+rng.uniform(-.13,.13),val,s=12+np.sqrt(r.n_cells)*1.2,facecolor=colors[i] if filled else 'white',edgecolor=colors[i],lw=.7,alpha=.9,zorder=3)
 ax.set_xticks(range(4),['Baseline','Rela','Nivo','Nivo + Rela'],rotation=25,ha='right');ax.set_ylabel('Median Module 1 score per patient' if j==0 else 'Joint-high cells per patient (%)')
ax=axes[2];panel(ax,'c','Cutoff sensitivity | cell-pooled')
s=pd.read_csv(O/'Sensitivity_cutoffs_and_patient_weighting.csv')
for group,color in zip(groups,colors):
 q=s[s.time_tx==group];ax.plot(q.reference_quantile*100,q.cell_pooled_joint_percent,'o-',c=color,lw=1,ms=4,label=names[group].split(' |')[0])
ax.set_xlabel('Reference percentile for both modules');ax.set_ylabel('Joint-high cells (%)');ax.set_xticks([65,70,75,80]);ax.legend(frameon=False,fontsize=6)
fig.text(.075,.045,'a–b: one point per patient-stage; open points indicate fewer than 20 late-bin cells. Box: median and interquartile range; whiskers: 1.5×IQR.\nAll patients retained; no cell-level significance tests. c: sensitivity of the reference-relative joint-high definition, not a clinical severity calibration.',fontsize=7,color=grey)
save(fig,'Figure_S1_patient_and_threshold_sensitivity')

# FIGURE 3: original plots of published clinical aggregates. No invented patient-level KM trajectories.
fig=plt.figure(figsize=(12.8,9.6));gs=fig.add_gridspec(2,2,left=.085,right=.96,top=.85,bottom=.19,hspace=.70,wspace=.65)
fig.text(.085,.967,'Figure 3 | Long-term clinical outcomes after Nivo + Rela',fontsize=15,fontweight='bold')
fig.text(.085,.940,'Independent clinical cohorts | Published response counts, landmark estimates and hazard ratios',fontsize=9,color=grey)
fig.text(.085,.913,'a–c: RELATIVITY-047, advanced melanoma | d: NCT02519322, resectable melanoma, Nivo + Rela plus surgery | No pooled analysis',fontsize=8,color=grey)
ax=fig.add_subplot(gs[0,0]);panel(ax,'a','Best overall response | RELATIVITY-047')
r=pd.read_csv(O/'Fig3_clinical_best_response.csv')
for i,(arm,color) in enumerate([('Nivo + Rela',red),('Nivo',navy)]):
 q=r[r.arm==arm].set_index('response').loc[['CR','PR','SD','PD']];xp=np.arange(4)+(i-.5)*.34
 ax.bar(xp,q.percent,width=.32,color=color,label=arm)
 for xx,(_,row) in zip(xp,q.iterrows()):ax.text(xx,row.percent+1.3,f'{row.percent:.1f}%\n(n={row.n})',ha='center',va='bottom',fontsize=6.5)
ax.set_xticks(range(4),['CR','PR','SD','PD']);ax.set_ylim(0,56);ax.set_ylabel('Randomized patients (%)');ax.legend(frameon=False,fontsize=7,loc='upper left')
ax.text(.0,-.20,'Nivo + Rela: n=355; Nivo: n=359. CR is not a cure endpoint.',transform=ax.transAxes,fontsize=7,color=grey)
ax=fig.add_subplot(gs[0,1]);panel(ax,'b','Five-year survival estimates | RELATIVITY-047')
land=pd.read_csv(O/'Fig3_clinical_landmark_estimates.csv');q=land[land.trial=='RELATIVITY-047'];ends=['PFS','OS','MSS']
for i,(arm,color) in enumerate([('Nivo + Rela',red),('Nivo',navy)]):
 w=q[q.arm==arm].set_index('endpoint').loc[ends]
 yy=np.arange(3)+(i-.5)*.22;ax.scatter(w.estimate_percent,yy,s=42,c=color,label=arm,zorder=3)
 for xx,y in zip(w.estimate_percent,yy):ax.text(xx+2.5,y,f'{xx:.0f}%',va='center',fontsize=8,color=color)
ax.set_yticks(range(3),ends);ax.invert_yaxis();ax.set_xlim(0,100);ax.set_ylim(2.5,-.5);ax.set_xlabel('Published estimate at 60 months (%)');ax.legend(frameon=False,fontsize=7,loc='lower right')
ax.text(0,-.22,'Landmarks transcribed as published; no CI or KM curve inferred.',transform=ax.transAxes,fontsize=7,color=grey)
ax=fig.add_subplot(gs[1,0]);panel(ax,'c','Relative treatment effects | RELATIVITY-047')
h=pd.read_csv(O/'Fig3_clinical_hazard_ratios.csv');ax.axvline(1,color=grey,ls='--',lw=.8)
for i,row in h.iterrows():
 ax.errorbar(row.HR,i,xerr=np.array([[row.HR-row.CI95_low],[row.CI95_high-row.HR]]),fmt='o',c=red,capsize=3,lw=1.3,ms=5)
 ax.text(1.06,i,f'{row.HR:.2f} ({row.CI95_low:.2f}–{row.CI95_high:.2f})',va='center',fontsize=8)
ax.set_yticks(range(3),h.endpoint);ax.set_ylim(2.6,-.6);ax.set_xlim(.5,1.47);ax.set_xticks([.5,.75,1,1.25]);ax.set_xlabel('Hazard ratio (95% confidence interval)')
ax.text(.02,.04,'HR < 1 favors Nivo + Rela',transform=ax.transAxes,fontsize=7,color=grey)
ax=fig.add_subplot(gs[1,1]);panel(ax,'d','Nivo + Rela plus surgery | NCT02519322')
q=land[land.trial=='NCT02519322'].copy();order=[('RFS','MPR'),('RFS','Less than MPR'),('EFS','All treated'),('OS','All treated')]
descriptions=['RFS | MPR','RFS | less than MPR','EFS | all treated','OS | all treated']
for i,(endpoint,arm) in enumerate(order):
 row=q[(q.endpoint==endpoint)&(q.arm==arm)].iloc[0];color=teal if i==0 else red if i==1 else navy
 ax.hlines(i,0,row.estimate_percent,color=color,alpha=.24,lw=7);ax.scatter(row.estimate_percent,i,color=color,s=40,zorder=3);ax.text(row.estimate_percent+2,i,f'{row.estimate_percent:.0f}%',va='center',fontsize=8,color=color)
ax.set_yticks(range(4),descriptions,fontsize=7);ax.set_ylim(3.6,-.6);ax.set_xlim(0,107);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Published estimate at 48 months (%)')
ax.text(0,-.24,'NCT02519322: 30 treated; 29 underwent surgery.\nMPR: ≤10% viable tumor. RFS is not a cure estimate.',transform=ax.transAxes,fontsize=7,color=grey)
fig.text(.085,.047,'a–c: Long et al., Nature Medicine 2026, doi:10.1038/s41591-026-04756-1 (5-year update). d: Burton et al., JCO 2025, doi:10.1200/JCO-25-00494.\nPFS: progression-free survival (progression or death); OS: overall survival; MSS: melanoma-specific survival; RFS: recurrence-free survival; EFS: event-free survival.\nClinical estimates are independent of the single-cell cohort. Neither clinical failure nor its cause can be assigned to a particular T-cell state from these data.',fontsize=7,color=grey)
save(fig,'Figure_3_long_term_clinical_outcomes')
print('Four figures and exact plotted source values saved to',O)

# Replot TOX directly from the delivered normalized expression values.
plt.rcdefaults()
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none'})

t=b['t'];cmap=old_effector_palette
fig,axes=plt.subplots(1,2,figsize=(10,4.6));fig.subplots_adjust(left=.07,right=.95,top=.78,bottom=.20,wspace=.28)
limits=t.TOX.quantile([.02,.98]).to_numpy()
if limits[1]<=limits[0]:limits[1]=t.TOX.max()
for ax,group,title in zip(axes,['Baseline','combo'],['Baseline tumor CD8','Nivo + Rela | week 4']):
 d=t[t.time_tx==group].sort_values('TOX');im=ax.scatter(d.UMAP_1,d.UMAP_2,c=d.TOX,s=2.0,lw=0,cmap=cmap,vmin=limits[0],vmax=limits[1],rasterized=True)
 ax.set_title(f'{title} | {len(d):,} cells',loc='left');ax.set_xticks([]);ax.set_yticks([]);ax.set_xlabel('UMAP 1');ax.set_ylabel('UMAP 2');ax.spines[['top','right']].set_visible(False)
 for cl,g in t.groupby('cluster_id'):ax.text(g.UMAP_1.median(),g.UMAP_2.median(),f'C{cl}',fontsize=6,ha='center',bbox=dict(facecolor='white',alpha=.75,pad=.3,edgecolor='none'))
 ax.set_xlim(t.UMAP_1.min()-.5,t.UMAP_1.max()+.5);ax.set_ylim(t.UMAP_2.min()-.5,t.UMAP_2.max()+.5)
fig.suptitle('TOX expression | Full GEO RNA assay, joined by unique cell barcode',fontsize=12,fontweight='bold',y=.95)
ca=fig.add_axes([.37,.14,.28,.02]);fig.colorbar(im,cax=ca,orientation='horizontal').set_label('Deposited RNA log-normalized expression',fontsize=7)
fig.text(.07,.02,'Common color scale from baseline/week-4 TILs; original UMAP and cluster IDs retained. High expression plotted last.\nTOX: thymocyte selection associated high mobility group box. RNA expression is not a standalone functional-exhaustion diagnosis.',fontsize=7,color='#596372')
for ext in ['png','pdf','svg']:fig.savefig(O/('TOX_feature_distribution.'+ext),dpi=300)
fig.savefig(R/'TOX_feature_distribution_preview.png',dpi=110);plt.close(fig)

# Complementary all-TIL view; thresholds stay fixed to the original late-bin reference.
fig,axes=plt.subplots(2,2,figsize=(10.8,8.8));fig.subplots_adjust(left=.08,right=.88,top=.86,bottom=.14,hspace=.38,wspace=.27)
colors=[];rows=[];hexrows=[];t=b['t'];cut=b['cut'];groups=['Baseline','rela','nivo','combo'];names=['Baseline','Rela | week 4','Nivo | week 4','Nivo + Rela | week 4'];extent=(-.55,2.8,-.60,1.67)
for ax,g,title in zip(axes.ravel(),groups,names):
 d=t[t.time_tx==g];h=ax.hexbin(d.Module_1,d.Module_8,C=np.repeat(100/len(d),len(d)),reduce_C_function=np.sum,mincnt=1,gridsize=26,extent=extent,cmap='Blues',linewidths=0);colors.append(h)
 for (xx,yy),val in zip(h.get_offsets(),h.get_array()):hexrows.append(dict(time_tx=g,module1_center=xx,module8_center=yy,n_cells=int(round(val*len(d)/100)),percent=val))
 ax.axvline(cut.Module_1,c='#657083',ls='--',lw=.7);ax.axhline(cut.Module_8,c='#657083',ls='--',lw=.7)
 pct=100*(d.exhaustion_reference_high & d.cytotoxic_reference_high).mean();ax.text(.97,.97,f'Joint high: {pct:.2f}%',transform=ax.transAxes,ha='right',va='top',color='#C52E38',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',alpha=.9))
 ax.set_title(f'{title} | {len(d):,} cells, {d.patient_id.nunique()} patients',loc='left');ax.set_xlabel('Terminal exhaustion module (Module 1)');ax.set_ylabel('Cytotoxic module (Module 8)');ax.set_xlim(extent[:2]);ax.set_ylim(extent[2:]);ax.spines[['top','right']].set_visible(False)
 rows.append(dict(group=g,n_all_tumor_CD8=len(d),n_patients=d.patient_id.nunique(),joint_high_percent=pct,threshold_source='Unchanged original bins 8-10 reference, 70th percentile',selection='All baseline/week4 TIL cells, no bin-10 restriction'))
maxcolor=max(float(h.get_array().max()) for h in colors)
for h in colors:h.set_clim(0,maxcolor)
cax=fig.add_axes([.91,.31,.012,.40]);fig.colorbar(colors[0],cax=cax).set_label('Cells per hexagon (% of panel cells)',fontsize=7)
fig.suptitle('Supplementary Figure S2 | All tumor CD8 cells, without late-bin selection',fontsize=12,fontweight='bold',y=.96)
fig.text(.08,.025,'All 36,185 baseline/week-4 tumor CD8 cells are included. These panels answer an atlas-wide composition question.\nThresholds and author scores are unchanged; percentages are not expected to equal the conditional bin-10 results in Figure 2. No new inferential test is applied.',fontsize=7,color='#596372')
for ext in ['png','pdf','svg']:fig.savefig(O/('Figure_S2_all_tumor_CD8.'+ext),dpi=300)
fig.savefig(R/'Figure_S2_all_tumor_CD8_preview.png',dpi=110);plt.close(fig)
pd.DataFrame(rows).to_csv(O/'FigS2_all_TIL_summary.csv',index=False);pd.DataFrame(hexrows).to_csv(O/'FigS2_all_TIL_hexbins.csv',index=False)
print('Effector audit and all-TIL supplement completed',flush=True)

# Replot the historical display audit from the minimal supplied full-TIL table.
old=read("Effector_original_full_TIL.csv");old["final_clusters"]=old.final_clusters.astype(str)
new=b["t"][b["t"].time_tx=="combo"].copy()
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none'})
cmap=LinearSegmentedColormap.from_list('old_palette',['#E6E7E9','#F4BCA8','#BD1F2D']);lim=old.novershtern_eff_cd8.quantile([.02,.98]).to_numpy()
fig,axes=plt.subplots(2,2,figsize=(11,7.5));fig.subplots_adjust(left=.07,right=.93,top=.86,bottom=.16,hspace=.40,wspace=.22)
for i,(cohort,data) in enumerate([('Original full tumor atlas',old),('Nivo + Rela, week 4',new)]):
 for j,order in enumerate(['Random point order','High-score cells drawn last']):
  ax=axes[i,j];d=data.iloc[np.random.default_rng(813).permutation(len(data))] if j==0 else data.sort_values('novershtern_eff_cd8')
  im=ax.scatter(d.UMAP_1,d.UMAP_2,c=d.novershtern_eff_cd8,s=1.8,lw=0,cmap=cmap,vmin=lim[0],vmax=lim[1],rasterized=True)
  for cl in ['2','3','4','7']:
   g=old[old.final_clusters==cl];ax.text(g.UMAP_1.median(),g.UMAP_2.median(),'C'+cl,fontsize=7,ha='center',bbox={'facecolor':'white','alpha':.8,'pad':.5,'edgecolor':'none'})
  ax.set_title(f'{cohort} | n={len(data):,}\n{order}',loc='left');ax.set_xticks([]);ax.set_yticks([]);ax.set_xlabel('UMAP 1');ax.set_ylabel('UMAP 2');ax.spines[['top','right']].set_visible(False)
  ax.set_xlim(old.UMAP_1.min()-.5,old.UMAP_1.max()+.5);ax.set_ylim(old.UMAP_2.min()-.5,old.UMAP_2.max()+.5)
fig.suptitle('Display audit | Same effector scores, different cohorts and drawing order',fontsize=13,fontweight='bold',y=.97)
cax=fig.add_axes([.37,.11,.30,.015]);fig.colorbar(im,cax=cax,orientation='horizontal').set_label('Author Novershtern effector CD8 score | common limits',fontsize=7)
fig.text(.07,.018,'All panels use the original full-TIL 2nd–98th percentile limits and palette. Drawing high scores last changes visibility in dense regions.\nThe gene-set score itself is unchanged; C2/C3/C4 have higher mean effector scores than C7 in both cohorts.',fontsize=7,color='#596372')
for ext in ['png','pdf','svg']:fig.savefig(O/('Effector_display_audit.'+ext),dpi=300)
fig.savefig(R/'Effector_display_audit_preview.png',dpi=110);plt.close(fig)


print("Reproduced all 7 figure sets in:",O)
